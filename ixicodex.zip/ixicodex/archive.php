<?php get_header(); ?>

			<div id="content">
		<main id="main" role="main">

						
						<div class="row cf">
							<div class="wrap">
						<center>
							<?php
							the_archive_title( '<h1 class="archive-title">', '</h1>' );
							the_archive_description( '<div class="taxonomy-description">', '</div>' );
							?></center>
							
							<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="half">
							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> class="m-all t-all d-all">					
								<div class="box ">
										<div class="image">

								<?php if ( has_post_thumbnail() ) : ?>
	<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
		<div class="overlay"></div>
	<img src="<?php the_post_thumbnail_url(array(200, 350)); ?>"/><span class="more button">Go Forth</span>
	</a>
<?php endif; ?></div>

								<div class="content"><h2>
																	
									<?php the_title(); ?></h2>
									</div></div></article></div>

							<?php endwhile; ?>
<div class="center">
	
								
									<?php ixicodex_page_navi(); ?><br>
</div>
							<?php else : ?>

								

							<?php endif; ?>

						</main>

				

				</div>

			</div>

<?php get_footer(); ?>
