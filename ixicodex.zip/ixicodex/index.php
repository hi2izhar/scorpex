<?php get_header(); ?>

	<div id="content">
		<main id="main" role="main">

						
						<div class="row cf featured-1">
							<div class="wrap">

							<?php if (have_posts()) : the_post(); ?>

							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> class="m-all t-all d-all">
								<div class="box">
										<div class="image">

								<?php if ( has_post_thumbnail() ) : ?>
	<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
		<div class="overlay"></div>
	<img src="<?php the_post_thumbnail_url(array(1000, 1000)); ?>"/><span class="more button">Go Forth</span>
	</a>
<?php endif; ?></div>

								<div class="content " style="color:blue;font-size:12px; padding: 10px;">
									<h2>
												
									<?php the_title(); ?></h2>
									<span >								
										  <?php the_excerpt(); ?></span>
									
									</div></div></article><?php else : ?><?php endif; ?>
							</div>
						</div>
			
			
			
			<div class="row cf ">
				
				
							<div class="wrap ">

							<?php query_posts('showposts=3'); ?>
<?php $ixposts = get_posts('numberposts=3&offset=0'); foreach ($ixposts as $post) : $count1++ ?>
<?php static $count1 = 0; if ($count1 == "3") { break; } else { ?>

								
								
								
								
								
<div class="half">
							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> class="m-all t-1of2 d-1of3">					
								<div class="box ">
										<div class="image">

								<?php if ( has_post_thumbnail() ) : ?>
	<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
		<div class="overlay"></div>
	<img src="<?php the_post_thumbnail_url(array(200, 350)); ?>"/><span class="more button">Go Forth</span>
	</a>
<?php endif; ?></div>

								<div class="content"><h2>
																	
									<?php the_title(); ?></h2>
									</div></div></article></div><?php $count1++; } ?>
<?php endforeach; ?>
							
						</div>	</div>
			
						<div class="row cf feature-rise">
				<div class="wrap">
				
					<?php
				$args = array(
					
    'post_type' => 'post',
	'orderby'   => 'rand',
    'posts_per_page' => 4,
);
$arr_posts = new WP_Query( $args ); ?>
			<span class="label button" >Trending</span>
				<?php query_posts('showposts=3'); ?>
<?php if ( $arr_posts->have_posts() ) : while ( $arr_posts->have_posts() ) : $arr_posts->the_post(); ?>
<div class="four">
							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> class="m-all t-1of2 d-1of3">					
								<div class="box ">
										<div class="image">

								<?php if ( has_post_thumbnail() ) : ?>
	<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
		<div class="overlay"></div>
	<img src="<?php the_post_thumbnail_url(array(200, 350)); ?>"/><span class="more button">Go Forth</span>
	</a>
<?php endif; ?></div>

								<div class="content"><h2>
																	
									<?php the_title(); ?></h2>
									
									</div></div></article></div><?php endwhile; endif; ?>

			
			</div></div>
			
			<div class="row cf featured-2">
				
				
							<div class="wrap ">

							<?php query_posts('showposts=1'); ?>
<?php $ixposts = get_posts('numberposts=1&offset=6'); foreach ($ixposts as $post) : $count3++; ?>
<?php static $count3 = 0; if ($count3 == "1") { break; } else { ?>

							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> class="m-all t-all d-all">					
								<div class="box ">
										<div class="image">

								<?php if ( has_post_thumbnail() ) : ?>
	<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
		<div class="overlay"></div>
	<img src="<?php the_post_thumbnail_url(array(200, 350)); ?>"/><span class="more button">Go Forth</span>
	</a>
<?php endif; ?></div>

								<div class="content " style="color:blue;font-size:12px; padding: 10px;">
									<h2>
												
									<?php the_title(); ?></h2>
																
									</div></div>
								<aside id="secondary" class="widget-area content-border-color box">
											<div id="secondary-P2" class="secondary-ad-widget">
												<?php if ( is_active_sidebar( 'sidebar5' ) ) : ?>

            <?php dynamic_sidebar( 'sidebar5' ); ?>

          <?php else : ?>

            <!-- This content shows up if there are no widgets defined in the backend. -->

            <div class="alert alert-danger">
              <p><?php _e( 'Activate Advertisement Widgets.', 'ixicodex' );  ?></p>
            </div>

          <?php endif; ?>
												</div>
										</aside>
								</article><?php $count3++; } ?>
<?php endforeach; ?>
							
						</div>	</div>	
			
			<div class="row cf ">
				
				
							<div class="wrap ">

							<?php query_posts('showposts=3'); ?>
<?php $ixposts = get_posts('numberposts=3&offset=3'); foreach ($ixposts as $post) : $count2++; ?>
<?php static $count2 = 0; if ($count2 == "3") { break; } else { ?>
<div class="half">
							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> class="m-all t-1of2 d-1of3">					
								<div class="box ">
										<div class="image">

								<?php if ( has_post_thumbnail() ) : ?>
	<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
		<div class="overlay"></div>
	<img src="<?php the_post_thumbnail_url(array(200, 350)); ?>"/><span class="more button">Go Forth</span>
	</a>
<?php endif; ?></div>

								<div class="content"><h2>
																	
									<?php the_title(); ?></h2>
									</div></div></article></div><?php $count2++; } ?>
<?php endforeach; ?>
							
						</div>	</div>
			<div class="row cf featured-3 feature-rise">
				<div class="wrap">
				
					<?php
				$args = array(
    'post_type' => 'post',
	'orderby'   => 'rand',
    'posts_per_page' => 1,
);
$arr_posts = new WP_Query( $args ); ?>
			<span class="label button" >Top Story</span>
				
<?php if ( $arr_posts->have_posts() ) : while ( $arr_posts->have_posts() ) : $arr_posts->the_post(); ?>
<div class="full">
							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> class="m-all t-all d-all">					
								<div class="box ">
										<div class="image">

								<?php if ( has_post_thumbnail() ) : ?>
	<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
		<div class="overlay"></div>
	<img src="<?php the_post_thumbnail_url(array(200, 350)); ?>"/><span class="more button">Go Forth</span>
	</a>
<?php endif; ?></div>

								<div class="content " style="color:blue;font-size:12px; padding: 10px;">
									<h2>
												
									<?php the_title(); ?></h2>
									<span >								
										  <?php the_excerpt(); ?></span>
									
									</div></div></article></div><?php endwhile; endif; ?>

			
			</div></div>

<div class="row cf ">
				
				
							<div class="wrap ">

							<?php query_posts('showposts=6'); ?>
<?php $ixposts = get_posts('numberposts=6&offset=7'); foreach ($ixposts as $post) : $count4++; ?>
<?php static $count4 = 0; if ($count4 == "6") { break; } else { ?>
<div class="half">
							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> class="m-all t-1of2 d-1of3">					
								<div class="box ">
										<div class="image">

								<?php if ( has_post_thumbnail() ) : ?>
	<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
		<div class="overlay"></div>
	<img src="<?php the_post_thumbnail_url(array(200, 350)); ?>"/><span class="more button">Go Forth</span>
	</a>
<?php endif; ?></div>

								<div class="content"><h2>
																	
									<?php the_title(); ?></h2>
									</div></div></article></div><?php $count4++; } ?>
<?php endforeach; ?>
							
						</div>	</div>			
			
			</div>		

			</main><!-- #main -->

			


<?php get_footer(); ?>
