				<footer class="footer cf">
                <div class="left-bg">
					
				</div>
                <div class="row cf">
                    <div class="m-all t-all d-1of4 first"><div class="bg">
						
						
						
						</div>
						<div style="color:black;" class="h1"><a href="<?php echo home_url(); ?>" rel="nofollow"><?php bloginfo('name'); ?></a></div><div class="inner">
						<span id="menu-footer-1" class="" style="font-color:black;">
						
						<?php wp_nav_menu(array(
    					'container' => 'div',                           // enter '' to remove nav container (just make sure .footer-links in _base.scss isn't wrapping)
    					'container_class' => 'footer-links cf',         // class of container (should you choose to use it)
    					'menu' => __( 'footer-menu', 'ixicodex' ),   // nav name
    					'menu_class' => 'footer-nav',            // adding custom nav class
    					'theme_location' => 'footer-links',             // where it's located in the theme
    					'before' => '',                                 // before the menu
    					'after' => '',                                  // after the menu
    					'link_before' => '',                            // before each link
    					'link_after' => '',                             // after each link
    					'depth' => 0,                                   // limit the depth of the nav
    					'fallback_cb' => 'bones_footer_links_fallback'  // fallback function
						)); ?>
					</span></div>
                        </div>	
						
						<div class="m-all t-1of2 d-1of4">
						<div id="sidebar" class="col-md-4 padding-5">

          <?php if ( is_active_sidebar( 'sidebar2' ) ) : ?>

            <?php dynamic_sidebar( 'sidebar2' ); ?>

          <?php else : ?>

            <!-- This content shows up if there are no widgets defined in the backend. -->

            <div class="alert alert-danger">
              <p><?php _e( 'Activate Footer-1 Widgets.', 'ixicodex' );  ?></p>
            </div>

          <?php endif; ?>

		</div>
						</div>
						
  <div class="m-all t-1of2 d-1of4">
						<div id="sidebar" class="col-md-4 padding-5">

          <?php if ( is_active_sidebar( 'sidebar3' ) ) : ?>

            <?php dynamic_sidebar( 'sidebar3' ); ?>

          <?php else : ?>

            <!-- This content shows up if there are no widgets defined in the backend. -->

            <div class="alert alert-danger">
              <p><?php _e( 'Activate Footer-2 Widgets.', 'ixicodex' );  ?></p>
            </div>

          <?php endif; ?>

		</div>
						</div>
					<div class="m-all t-1of2 d-1of4">
						<div id="sidebar" class="col-md-4 padding-5">

          <?php if ( is_active_sidebar( 'sidebar4' ) ) : ?>

            <?php dynamic_sidebar( 'sidebar4' ); ?>

          <?php else : ?>

            <!-- This content shows up if there are no widgets defined in the backend. -->

            <div class="alert alert-danger">
              <p><?php _e( 'Activate Footer-3 Widgets.', 'ixicodex' );  ?></p>
            </div>

          <?php endif; ?>

		</div>
						</div>   
				
</div>
				

			</footer>

		

		<?php // all js scripts are loaded in library/bones.php ?>
		<?php wp_footer(); ?>

	</body>

</html> <!-- end of site. what a ride! -->
