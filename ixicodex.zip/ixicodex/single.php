<?php get_header(); ?>

			
<center>
				<div id="inner-content" class="wrap cf">

					<main id="main" class="m-all t-all d-all cf seventy" role="main" >

						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<br><br>
							
						<h2>
													
						<?php the_title(); ?></h2>
								<?php the_content(); ?>
<div class="arrowNav">
	<div class="arrowLeft">
		<?php previous_post_link('%link', '&#8606;', FALSE); ?>
	</div>
	<div class="arrowRight">
		<?php next_post_link('%link', '&#8608;', FALSE); ?>
	</div>
</div>	

						<?php endwhile; ?>

						<?php else : ?>

							
						

						<?php endif; ?>
						
						<?php
						$previous_post = get_adjacent_post(false, '', true);
						$next_post = get_adjacent_post(false, '', false);
						?>
						
						<?php if($next_post): ?>
						
						<center>
					<div id="next-button"><span>
						<?php next_post_link('%link', 'Next Post', false); ?>
  					</span>
					</div>
					
					</center> <?php else: ?>		
						
						
						<center>
					<div id="next-button"><span>
						<?php previous_post_link('%link', 'Previous Post', false); ?>
  					</span>
					</div>
					
					</center> 
					<?php endif; ?>	
					
					</main>
					
					<div class="m-all t-1of2 d-1of4 thirty">
						<br><br>
						<div id="sidebar" class="col-md-4">

          <?php if ( is_active_sidebar( 'sidebar6' ) ) : ?>

            <?php dynamic_sidebar( 'sidebar6' ); ?><?php endif; ?>	
					
				</div></div></div>

</center>			

<?php get_footer(); ?>
